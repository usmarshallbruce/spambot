const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const FireSimple = require("./firebase.js");
const client = new Client({
  authStrategy: new LocalAuth({ clientId: 'WhatsappBot', dataPath: 'chorme' }),
  takeoverOnConflict: true,
  puppeteer: { args: ['--disable-dev-shm-usage', '--no-sandbox', '--disable-setuid-sandbox'] }
});

const donos = ["5562991001664"]

const db = new FireSimple({
  apiKey: "AIzaSyCUYO5nuxYSlawG_eVyUVQu3DlWEQHBWD8",
  databaseURL: "https://spambot2-default-rtdb.firebaseio.com",
});

client.on('qr', qr => {
  qrcode.generate(qr, { small: true });
});

let config = require("./config.json");

function reloadConfig() {
  try {
    delete require.cache[require.resolve(`./config.json`)];
    config = require("./config.json");
  } catch(err) {
    console.log("❌ | ERRO AO CARREGAR O ARQUIVO [ config.json ]")
  }
}

setInterval(() => {reloadConfig()}, 100);


client.on('ready', function () {
  const segs = [30, 60, 120]
  console.log('SPAM-BOT INICIADO COM SUCESSO !');
  setInterval(async function () {
    let limite = await db.get(`envio/${config.ENVIOS.CLIENTE}/limite`);
    let message_enviada = await db.get(`envio/${config.ENVIOS.CLIENTE}/sendeds`);
    const perfil = await db.get(`envio/${config.ENVIOS.CLIENTE}/status`);
    if(!perfil) return;
    if(!limite) return;
    if(message_enviada == limite || message_enviada > limite) {
      db.set(`envio/${config.ENVIOS.CLIENTE}`, {
        status: 0
      });
      return;
    }
   
    if (perfil == 1) {

      let base = config.ENVIOS.BASE;

      for(let i = 0 ; i < base.length ; i++) {
          base = base.replace(config.ENVIOS.NUMERO_ALEATORIO, Math.floor(Math.random() * 9))
      }

      const numero_final = base + "@c.us";
      try {
        client.sendMessage(numero_final, config.ENVIOS.MENSAGEM);
        db.set(`envio/${config.ENVIOS.CLIENTE}`, {
          sendeds: message_enviada + 1
        });
      } catch (error) {
        console.log("Não foi possivel enviar mensagem ao numero: " + base);
      }
    } else {
      return;
    }
  }, 1000 * segs[Math.floor(Math.random() * segs.length)]);
  
});

client.on("message", async function (message) {
  const user = await message.getContact();
  const number = `+${user.id.user}`;
  const chatID = number.substring(1) + "@c.us";
  const menu_get = await db.get(`menu/${config.ENVIOS.CLIENTE}/${user.id.user}`);
  let args = message.body.slice("!").trim().split(/ +/g);

  if(args[0].toLowerCase() == "limite" && donos.includes(user.id.user)) {
    if(isNaN(args[1])) {
      client.sendMessage(chatID, `❌ Não posso adicionar letras como limite.`);
    } else {
      client.sendMessage(chatID, `✅ Foram adicionadas *${args[1]}* mensagens de limite na conta atual.`);
      db.set(`envio/${config.ENVIOS.CLIENTE}`, {
        limite: parseInt(args[1]),
        sendeds: 0
      });
    }
    return;
  }

  if (message.body.toLowerCase() == "menu" && user.id.user == config.ENVIOS.CLIENTE) {
    let envio_status_message = await db.get(`envio/${config.ENVIOS.CLIENTE}/status`);
    let msg_envio;

    if(!envio_status_message || envio_status_message != 1) {
      msg_envio = "🔴 Desligado"
    } else {
      msg_envio = "🟢 Ligado"
    }

    let limite = await db.get(`envio/${config.ENVIOS.CLIENTE}/limite`);
    let message_enviada = await db.get(`envio/${config.ENVIOS.CLIENTE}/sendeds`);

    if(message_enviada == null) message_enviada = 0;
    if(limite == null) limite = 0;

    let message_menu = `* BEM VINDOª AO SPAM-BOT *\n\n`
    message_menu += `*1 | Iniciar o envio de mensagem*\n`
    message_menu += `*2 | Parar o envio de mensagem*\n\n`
    message_menu += `*💻 | Status do envio:* *${msg_envio}*\n`
    message_menu += `*📤 | Limite de envio:* *${message_enviada}/${limite}*\n`
    message_menu += `\nDigite a opção desejada: `
    await client.sendMessage(chatID, message_menu);
    await db.set(`menu/${config.ENVIOS.CLIENTE}/${user.id.user}`, { menu: 1 });
    return;
  }

  if (message.body == "1" && menu_get != null && menu_get.menu == 1) {
    let status_envio = await db.get(`envio/${config.ENVIOS.CLIENTE}/status`);
    if (status_envio == 1) {
      client.sendMessage(chatID, "❌ O envio ja esta em execução.");
      db.delete(`menu/${config.ENVIOS.CLIENTE}/${user.id.user}`);
      return;
    } else {
      let limite = await db.get(`envio/${config.ENVIOS.CLIENTE}/limite`);
      let message_enviada = await db.get(`envio/${config.ENVIOS.CLIENTE}/sendeds`);
      if(!limite) {
        client.sendMessage(chatID, `*❌ Você não possui limite disponivel.*`);
        db.delete(`menu/${config.ENVIOS.CLIENTE}/${user.id.user}`);
        return;
      }
      if(message_enviada >= limite) {
        client.sendMessage(chatID, `*❌ Seu limite de mensagens acabou.*`);
        db.delete(`menu/${config.ENVIOS.CLIENTE}/${user.id.user}`);
        return;
      }
      client.sendMessage(chatID, "*✅ Envio iniciado com sucesso !*");
      db.set(`envio/${config.ENVIOS.CLIENTE}`, { status: 1 });
      db.delete(`menu/${config.ENVIOS.CLIENTE}/${user.id.user}`)
    }
  } else if (message.body == "2" && menu_get != null && menu_get.menu == 1) {
    let status_envio = await db.get(`envio/${config.ENVIOS.CLIENTE}/status`);
    if (status_envio != null && status_envio == 1) {
      client.sendMessage(chatID, "*✅ Envio parado com sucesso !*");
      db.set(`envio/${config.ENVIOS.CLIENTE}`, { status: 0 });
      db.delete(`menu/${config.ENVIOS.CLIENTE}/${user.id.user}`);
    } else {
      client.sendMessage(chatID, "*❌ O envio ja esta parado.*");
      db.delete(`menu/${config.ENVIOS.CLIENTE}/${user.id.user}`)
    }
  } else if (menu_get != null && menu_get.menu == 1) {
    client.sendMessage(chatID, "*❌ Opção invalida. digite* ```menu``` *para ver as opções disponiveis.*");
    db.delete(`menu/${config.ENVIOS.CLIENTE}/${user.id.user}`);
  }
});

client.initialize();